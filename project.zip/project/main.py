#!/usr/bin/python3
#-*- coding: utf-8 -*-

import search_moviename

if __name__ == '__main__':
	for i in range(10001,10010):
		search_moviename.integrate(str(i))
	
